- Added menu item.

- Forward  -> Light to Dark 
- Reverese -> Dark to light

